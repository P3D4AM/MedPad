import { createHash, randomBytes } from 'crypto'
import { cookies } from 'next/headers'
import { db } from '@/lib/db'

export const ADMIN_COOKIE = 'medpad_admin'
export const APP_TOKEN_HEADER = 'x-medpad-token'

export const sha256 = (s: string) => createHash('sha256').update(s).digest('hex')

export function newToken(): string {
  return randomBytes(24).toString('hex')
}

/** Admin auth via cookie — returns true when session valid */
export async function isAdmin(): Promise<boolean> {
  const jar = await cookies()
  const tok = jar.get(ADMIN_COOKIE)?.value
  if (!tok) return false
  const row = await db.config.findUnique({ where: { key: 'adminSession' } })
  return !!row && row.value === tok
}

/** Employee (app) auth via header or ?token= — returns employee or null */
export async function appEmployee(req: Request) {
  const url = new URL(req.url)
  let tok = req.headers.get(APP_TOKEN_HEADER) || ''
  if (!tok) tok = url.searchParams.get('token') || ''
  if (!tok) return null
  const row = await db.appToken.findUnique({ where: { token: tok }, include: { employee: true } })
  if (!row || !row.employee.active) return null
  // refresh lastUsed (fire & forget)
  db.appToken.update({ where: { token: tok }, data: { lastUsedAt: new Date() } }).catch(() => {})
  return row.employee
}

export async function getConfig(key: string, def = ''): Promise<string> {
  const row = await db.config.findUnique({ where: { key } })
  return row?.value ?? def
}

export async function setConfig(key: string, value: string) {
  await db.config.upsert({ where: { key }, update: { value }, create: { key, value } })
}

/** Socket token shared between panel & realtime service (from env or config) */
export function socketToken(): string {
  return process.env.SOCKET_TOKEN || 'medpad-dev-token'
}
