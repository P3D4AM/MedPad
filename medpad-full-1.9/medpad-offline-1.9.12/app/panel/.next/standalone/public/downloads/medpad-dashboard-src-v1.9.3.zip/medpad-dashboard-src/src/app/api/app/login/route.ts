import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { newToken, sha256 } from '@/lib/auth'

/** Employee app login → issues bearer token (no guest mode) */
export async function POST(req: Request) {
  const { username, password } = await req.json().catch(() => ({ username: '', password: '' }))
  if (!username || !password) {
    return NextResponse.json({ ok: false, error: 'نام کاربری و رمز لازم است' }, { status: 400 })
  }
  const emp = await db.employee.findUnique({ where: { username: String(username).trim() } })
  if (!emp || !emp.active || emp.password !== sha256(password)) {
    return NextResponse.json({ ok: false, error: 'نام کاربری یا رمز اشتباه است' }, { status: 401 })
  }
  const token = newToken()
  await db.appToken.create({ data: { token, employeeId: emp.id } })
  return NextResponse.json({
    ok: true,
    token,
    employee: { id: emp.id, name: emp.name, username: emp.username },
  })
}
