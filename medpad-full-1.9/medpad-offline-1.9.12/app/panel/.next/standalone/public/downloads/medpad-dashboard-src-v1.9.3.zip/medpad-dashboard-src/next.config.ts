import type { NextConfig } from "next";
import path from "path";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // v1.9.3 fix: Turbopack misdetects the workspace root when the installer is
  // unpacked next to another Node project (parent bun.lock/package-lock.json).
  // Pinning the root prevents files leaking into the neighbor project and
  // broken builds — the same bug that was found during E2E testing.
  turbopack: {
    root: path.resolve(__dirname),
  },
};

export default nextConfig;
