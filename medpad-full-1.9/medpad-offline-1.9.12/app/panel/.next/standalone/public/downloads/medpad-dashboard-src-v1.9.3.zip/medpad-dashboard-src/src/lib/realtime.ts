'use client'

import { useEffect, useRef } from 'react'
import { io, type Socket } from 'socket.io-client'

export interface PanelConfigInfo {
  panelVersion: string
  apkVersion: string
  socketMode: 'gateway' | 'direct'
}

/**
 * Connect to the MedPad realtime service.
 *  - gateway mode (sandbox/Caddy): same-origin path + XTransformPort query
 *  - direct mode (installer): ws(s)://host:3003
 */
export function connectRealtime(cfg: PanelConfigInfo): Socket {
  if (cfg.socketMode === 'direct') {
    const proto = location.protocol === 'https:' ? 'https' : 'http'
    return io(`${proto}://${location.hostname}:3003`, { path: '/socket.io', transports: ['polling', 'websocket'] })
  }
  return io('/', {
    path: '/socket.io',
    query: { XTransformPort: '3003' },
    transports: ['polling', 'websocket'],
  })
}

/** Ask once for browser notification permission (no-op on insecure origins) */
export function requestNotifyPermission(): void {
  try {
    if (typeof window !== 'undefined' && 'Notification' in window && location.protocol === 'https:') {
      if (Notification.permission === 'default') Notification.requestPermission()
    }
  } catch { /* ignore */ }
}

export function browserNotify(title: string, body: string): void {
  try {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body, dir: 'rtl', lang: 'fa' })
    }
  } catch { /* ignore */ }
}

/** Keeps a socket alive and dispatches events to a handler */
export function useRealtimeSocket(
  cfg: PanelConfigInfo | null,
  onEvent: (event: string, payload: unknown) => void,
): void {
  const handlerRef = useRef(onEvent)

  useEffect(() => {
    handlerRef.current = onEvent
  }, [onEvent])

  useEffect(() => {
    if (!cfg) return
    let sock: Socket | null = null
    let cancelled = false

    const connect = () => {
      sock = connectRealtime(cfg)
      const forward = (evt: string) => (payload: unknown) => handlerRef.current(evt, payload)
      const events = ['hello', 'checkin', 'checkout', 'notification', 'proximity', 'customer-added']
      sock.on('connect', () => console.log('[rt] connected'))
      sock.on('disconnect', () => console.log('[rt] disconnected'))
      for (const e of events) sock.on(e, forward(e))
    }
    connect()

    // watchdog: reconnect if dropped
    const iv = setInterval(() => {
      if (cancelled) return
      if (!sock || !sock.connected) {
        try { sock?.disconnect() } catch { /* noop */ }
        connect()
      }
    }, 10_000)

    return () => {
      cancelled = true
      clearInterval(iv)
      try { sock?.disconnect() } catch { /* noop */ }
    }
  }, [cfg])
}

/** Persian date/time formatting */
export function faDateTime(iso: string | Date): string {
  const d = new Date(iso)
  return d.toLocaleString('fa-IR', {
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit',
  })
}

export function faTime(iso: string | Date): string {
  return new Date(iso).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
}
