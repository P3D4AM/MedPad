/**
 * MedPad setup-server (v1.9.3) — local wizard backend.
 * Serves ui/index.html on :3199 and streams `install.mjs` output.
 * POST /api/run?mode=tunnel&tunnel-kind=domain&cf-token=..&cf-domain=..&subdomain=panel&non-interactive=1
 */
import http from 'http'
import { spawn } from 'child_process'
import { readFileSync } from 'fs'
import path from 'path'
import url from 'url'

const __dirname = path.dirname(url.fileURLToPath(import.meta.url))
const PORT = Number(process.env.SETUP_PORT || 3199)

const server = http.createServer((req, res) => {
  const u = new URL(req.url || '/', `http://localhost:${PORT}`)

  if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    res.end(readFileSync(path.join(__dirname, 'ui', 'index.html')))
    return
  }

  if (req.method === 'GET' && u.pathname === '/health') {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ ok: true, service: 'medpad-setup', ver: '1.9.3' }))
    return
  }

  if (req.method === 'POST' && u.pathname === '/api/run') {
    const args = ['install.mjs', '--non-interactive']
    for (const [k, v] of u.searchParams.entries()) {
      if (v && v.length < 500) args.push(`--${k}`, v)
    }
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' })
    const child = spawn(process.execPath, args, { cwd: __dirname })
    child.stdout.on('data', (d) => res.write(d))
    child.stderr.on('data', (d) => res.write(d))
    child.on('close', (code) => {
      res.write(`\n[installer exited with code ${code}]\n`)
      res.end()
    })
    req.on('close', () => {
      try { child.kill() } catch { /* noop */ }
    })
    return
  }

  res.writeHead(404, { 'content-type': 'application/json' })
  res.end(JSON.stringify({ ok: false, error: 'not found' }))
})

server.listen(PORT, () => {
  console.log(`✔ MedPad wizard ready → http://localhost:${PORT}`)
})
