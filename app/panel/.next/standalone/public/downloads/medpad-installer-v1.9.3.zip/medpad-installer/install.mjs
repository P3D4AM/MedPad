#!/usr/bin/env node
/**
 * MedPad Installer v1.9.3 — main pipeline (win-x64 / linux / mac)
 *
 * 7 steps: prepare → deps → database+admin → build → tunnel → services → health
 * Modes:  local (LAN) | quick (trycloudflare random URL) | domain (Named Tunnel, fixed URL)
 *
 * CLI: node install.mjs [--non-interactive] [--mode tunnel|local]
 *                      [--tunnel-kind quick|domain] [--cf-token T] [--cf-domain d] [--subdomain panel]
 *                      [--admin-user admin] [--admin-pass secret] [--port 3000]
 */
import { spawn, spawnSync } from 'child_process'
import {
  existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync, rmSync, cpSync,
} from 'fs'
import path from 'path'
import url from 'url'
import readline from 'readline'
import { stopMedPadServices, portBusy } from './services.mjs'

const __dirname = path.dirname(url.fileURLToPath(import.meta.url))
export const INSTALLER_VER = '1.9.3'
const PANEL_PORT = 3000
const RT_PORT = 3003

// ─── tiny CLI output helpers ────────────────────────────────
const step = (n, t) => console.log(`\n━━━ مرحله ${n} از 7: ${t} ━━━`)
const info = (m) => console.log(m)
const ok = (m) => console.log(`✓ ${m}`)
const warn = (m) => console.log(`⚠ ${m}`)
const err = (m) => console.log(`✗ ${m}`)

function arg(name, def = undefined) {
  const i = process.argv.indexOf(`--${name}`)
  if (i >= 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--')) return process.argv[i + 1]
  if (i >= 0) return true
  return def
}
const NON_INTERACTIVE = !!process.argv.includes('--non-interactive')

async function ask(question, def = '') {
  if (NON_INTERACTIVE) return def
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  return new Promise((res) =>
    rl.question(`${question}${def ? ` [${def}]` : ''}: `, (a) => {
      rl.close()
      res(a.trim() || def)
    }),
  )
}

function sh(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { stdio: opts.capture ? 'pipe' : 'inherit', encoding: 'utf8', shell: process.platform === 'win32', ...opts })
  return r
}

function findPm(panelDir) {
  // prefer bun → npm
  const bun = spawnSync('bun', ['--version'], { encoding: 'utf8', shell: process.platform === 'win32' })
  if (bun.status === 0 && existsSync(path.join(panelDir, 'bun.lock'))) return 'bun'
  return 'npm'
}

async function main() {
  const t0 = Date.now()
  console.log('╔══════════════════════════════════════════╗')
  console.log(`║   ⚙ MedPad Installer v${INSTALLER_VER}`)
  console.log('╚══════════════════════════════════════════╝')

  const installDir = path.resolve(arg('dir', path.join(__dirname, '..', 'medpad-install')))
  info(`📁 پوشه نصب: ${installDir}`)
  mkdirSync(installDir, { recursive: true })

  // ── free space check (win) ────────────────────────────────
  if (process.platform === 'win32') {
    const r = spawnSync('wmic', ['logicaldisk', 'get', 'size,freespace,caption'], { encoding: 'utf8', shell: true })
    if (r.status === 0) {
      const lines = r.stdout.split(/\r?\n/).filter((l) => l.trim())
      for (const line of lines) {
        const cols = line.trim().split(/\s+/)
        if (installDir.toUpperCase().startsWith(cols[0])) {
          const freeGB = Number(cols[1] || 0) / 1e9
          info(`💾 فضای آزاد: ${freeGB.toFixed(1)} گیگابایت`)
          if (freeGB < 3) err('فضای آزاد کمتر از ۳ گیگابایت است')
        }
      }
    }
  }

  // OneDrive warning (EPERM root cause #2)
  if (/onedrive/i.test(installDir)) {
    warn('پوشه نصب داخل OneDrive است — OneDrive فایل‌های Prisma را قفل می‌کند!')
    warn('توصیه جدی: نصب را به مسیری خارج از OneDrive منتقل کنید (مثلاً C:\\MedPad)')
  }

  // ═══ Step 1 — prepare files ══════════════════════════════
  step(1, 'آماده‌سازی فایل‌ها')
  const panelDir = path.join(installDir, 'panel')
  const srcPanel = path.join(__dirname, 'panel-src')
  const keepDb = existsSync(path.join(panelDir, 'db', 'custom.db'))
  if (!existsSync(srcPanel)) {
    err('panel-src پیدا نشد — بسته نصب‌کننده ناقص است')
    process.exit(1)
  }
  if (existsSync(panelDir)) {
    info('♻ نصب موجود شناسایی شد — سورس به‌روزرسانی می‌شود، دیتابیس حفظ می‌شود')
    // preserve db + uploads + .env
    const tmp = path.join(installDir, '.keep-tmp')
    rmSync(tmp, { recursive: true, force: true })
    for (const d of ['db', 'uploads', '.env']) {
      const s = path.join(panelDir, d)
      if (existsSync(s)) cpSync(s, path.join(tmp, d), { recursive: true })
    }
    rmSync(panelDir, { recursive: true, force: true })
    cpSync(srcPanel, panelDir, { recursive: true })
    for (const d of ['db', 'uploads', '.env']) {
      const s = path.join(tmp, d)
      if (existsSync(s)) cpSync(s, path.join(panelDir, d), { recursive: true })
    }
    rmSync(tmp, { recursive: true, force: true })
  } else {
    cpSync(srcPanel, panelDir, { recursive: true })
  }
  ok(`پنل در ${panelDir} آماده شد${keepDb ? ' (دیتابیس قبلی حفظ شد)' : ''}`)

  // ═══ Step 2 — node modules ═══════════════════════════════
  step(2, 'نصب وابستگی‌ها (Node Modules)')
  const pm = findPm(panelDir)
  if (existsSync(path.join(panelDir, 'node_modules', 'next')) && !process.argv.includes('--force-deps')) {
    info('♻ وابستگی‌ها از قبل نصب‌اند — رد شد')
  } else {
    info(`⬇ نصب با ${pm}…`)
    const r = sh(pm, ['install'], { cwd: panelDir })
    if (r.status !== 0) {
      err('نصب وابستگی‌ها ناموفق بود — اینترنت و آنتی‌ویروس را چک کنید')
      process.exit(1)
    }
    ok('وابستگی‌ها نصب شدند')
  }

  // ═══ Step 3 — env + database + admin ═════════════════════
  step(3, 'دیتابیس و حساب مدیر')
  const envPath = path.join(panelDir, '.env')
  let env = existsSync(envPath) ? readFileSync(envPath, 'utf8') : ''
  if (!env.includes('DATABASE_URL=')) {
    env += `\nDATABASE_URL=file:${path.join(panelDir, 'db', 'custom.db').replace(/\\/g, '/')}\n`
  }
  if (!env.includes('SOCKET_TOKEN=')) {
    env += `\nSOCKET_TOKEN=medpad-${Math.random().toString(36).slice(2, 12)}\n`
  }
  if (!env.includes('MEDPAD_SOCKET_MODE=')) {
    env += `\nMEDPAD_SOCKET_MODE=direct\n`
  }
  writeFileSync(envPath, env)
  info('🗄 فایل تنظیمات (.env) آماده شد')

  mkdirSync(path.join(panelDir, 'db'), { recursive: true })
  mkdirSync(path.join(panelDir, 'uploads', 'voice'), { recursive: true })

  // prisma generate — 5 retries + verification (EPERM hardening, v1.9.2)
  const prismaGen = async () => {
    const engDir = path.join(panelDir, 'node_modules', '.prisma', 'client')
    for (let attempt = 1; attempt <= 5; attempt++) {
      info(`⚙ تولید کلاینت Prisma (تلاش ${attempt}/5)…`)
      const r = sh('npx', ['prisma', 'generate'], { cwd: panelDir, capture: true })
      const engineOk = existsSync(path.join(engDir, 'libquery_engine')) || existsSync(path.join(engDir, 'query_engine-windows.dll.node')) || existsSync(path.join(engDir, 'libquery_engine-darwin')) || existsSync(path.join(engDir, 'libquery_engine-debian'))
      if (r.status === 0 && engineOk) {
        ok('کلاینت Prisma آماده شد')
        return true
      }
      warn('prisma generate ناموفق بود (فایل قفل‌شده — پروسه قبلی یا آنتی‌ویروس)…')
      await stopMedPadServices(panelDir)
      await new Promise((r2) => setTimeout(r2, attempt * 1500))
    }
    return false
  }
  if (!(await prismaGen())) {
    err('تولید Prisma بعد از ۵ تلاش ناموفق بود. راه‌حل:')
    err('  ۱) Task Manager → همه node.exe های MedPad را End Task کنید')
    err('  ۲) پوشه MedPad را در استثنائات آنتی‌ویروس/دیفندر قرار دهید')
    err('  ۳) اگر داخل OneDrive است، خارج از آن نصب کنید')
    err('  ۴) دوباره install.bat را اجرا کنید (دیتابیس حفظ می‌شود)')
    process.exit(1)
  }
  const push = sh('npx', ['prisma', 'db', 'push', '--accept-data-loss'], { cwd: panelDir, capture: true })
  if (push.status !== 0) {
    err('اعمال اسکیما به دیتابیس ناموفق بود:\n' + (push.stdout || '') + (push.stderr || ''))
    process.exit(1)
  }
  ok('دیتابیس آماده است')

  // admin account (seed) — keep existing, create if missing
  const adminUser = arg('admin-user', 'admin')
  let adminPass = arg('admin-pass')
  if (!adminPass && !keepDb) adminPass = 'admin123'
  if (adminPass) {
    const seed = sh('node', ['--input-type=module', '-e', `
      import { createHash } from 'crypto';
      import { PrismaClient } from '@prisma/client';
      const db = new PrismaClient();
      const sha = (s) => createHash('sha256').update(s).digest('hex');
      const cfg = { adminUser: ${JSON.stringify(adminUser)}, adminPassHash: sha(${JSON.stringify(adminPass)}), panelVersion: '${INSTALLER_VER}', apkVersion: '1.9.1' };
      for (const [key, value] of Object.entries(cfg)) await db.config.upsert({ where: { key }, update: { value }, create: { key, value } });
      const count = await db.employee.count();
      if (count === 0) {
        const names = [['ali','علی محمدی'],['sara','سارا احمدی'],['mahla','مهلا کریمی']];
        const emp = [];
        for (const [username, name] of names) emp.push(await db.employee.create({ data: { username, name, password: sha('1234') } }));
        const cus = [];
        const cs = [['دکتر رضایی — کلینیک سلامت',35.7448,51.3752],['دکتر محمدی — داروخانه نور',35.7010,51.3910],['دکتر کریمی — مطب شمال',35.7166,51.4160]];
        for (const [name, lat, lng] of cs) cus.push(await db.customer.create({ data: { name, lat, lng, address: 'تهران' } }));
        for (let i = 0; i < emp.length; i++) { await db.assignment.create({ data: { employeeId: emp[i].id, customerId: cus[i].id } }); await db.assignment.create({ data: { employeeId: emp[i].id, customerId: cus[(i+1)%3].id } }); }
      }
      await db.$disconnect();
      console.log('seed-ok');
    `], { cwd: panelDir, capture: true })
    if (seed.stdout?.includes('seed-ok')) ok('حساب مدیر و داده‌های اولیه آماده است')
    else warn('seed: ' + (seed.stderr || seed.stdout || '').slice(-200))
  } else {
    info('♻ حساب مدیر قبلی حفظ شد')
  }

  // ═══ Step 4 — build panel ════════════════════════════════
  step(4, 'بیلد پنل (Production)')
  const build = sh(pm === 'bun' ? 'node' : 'node', ['node_modules/next/dist/bin/next', 'build'], { cwd: panelDir })
  if (build.status !== 0) {
    err('بیلد پنل ناموفق بود')
    process.exit(1)
  }
  ok('پنل با موفقیت بیلد شد')

  // ═══ Step 5 — tunnel / address mode ══════════════════════
  step(5, 'تنظیم آدرس دسترسی')
  let mode = arg('mode')
  let tunnelKind = arg('tunnel-kind')
  if (!mode) {
    console.log(`
  حالت‌های آدرس:
    ۱) شبکه محلی — http://IP-کامپیوتر:3000 (سریع و پایدار داخل دفتر)
    ۲) تونل Cloudflare سریع — آدرس https تصادفی trycloudflare.com (موقتی)
    ۳) دامنه خودم — تنظیم خودکار، آدرس ثابت https://panel.دامنه-شما (پیشنهادی)`)
    const a = await ask('انتخاب (1/2/3)', '3')
    mode = a === '1' ? 'local' : 'tunnel'
    tunnelKind = a === '3' ? 'domain' : a === '2' ? 'quick' : 'quick'
  }
  const statePath = path.join(installDir, 'tunnel-state.json')
  const state = existsSync(statePath) ? JSON.parse(readFileSync(statePath, 'utf8')) : {}

  if (mode === 'local') {
    state.kind = 'local'
    info('حالت شبکه محلی انتخاب شد — آدرس: http://localhost:' + PANEL_PORT)
  } else if (tunnelKind === 'domain') {
    const cfToken = arg('cf-token') || process.env.CF_API_TOKEN || (await ask('🔑 Cloudflare API Token (Tunnel:Edit + DNS:Edit + Zone:Read)'))
    const cfDomain = arg('cf-domain') || (await ask('🌐 دامنه شما (مثلاً example.com)'))
    const subdomain = arg('subdomain') || (await ask('زیردامنه', 'panel'))
    if (!cfToken || !cfDomain) {
      err('توکن یا دامنه داده نشد — به حالت محلی برمی‌گردیم')
      state.kind = 'local'
    } else {
      info('☁ اتصال به Cloudflare…')
      const { setupDomainTunnel } = await import('./lib/cloudflare.mjs')
      try {
        const result = await setupDomainTunnel({
          token: cfToken,
          domain: cfDomain,
          subdomain,
          state: { tunnelId: state.tunnelId, service: `http://localhost:${PANEL_PORT}` },
        })
        // persist credentials (NOT the api token)
        const credDir = path.join(installDir, 'tunnel-creds')
        mkdirSync(credDir, { recursive: true })
        const credFile = path.join(credDir, `${result.tunnelId}.json`)
        writeFileSync(
          credFile,
          JSON.stringify({ AccountTag: result.accountTag, TunnelSecret: result.tunnelToken.split(':').pop(), TunnelID: result.tunnelId }, null, 2),
        )
        // cloudflared local config (protocol http2 — QUIC is blocked in IR)
        writeFileSync(
          path.join(credDir, 'config.yml'),
          `tunnel: ${result.tunnelId}\ncredentials-file: ${credFile.replace(/\\/g, '/')}\nprotocol: http2\n\ningress:\n  - hostname: ${result.hostname}\n    service: http://localhost:${PANEL_PORT}\n  - service: http_status:404\n`,
        )
        state.kind = 'domain'
        state.tunnelId = result.tunnelId
        state.hostname = result.hostname
        state.publicUrl = `https://${result.hostname}`
        ok(`✅ آدرس ثابت شما: ${state.publicUrl}`)
        ok(`DNS CNAME ${result.dnsCreated ? 'ساخته شد' : 'از قبل درست بود'}`)
      } catch (e) {
        err(`تنظیم دامنه ناموفق بود: ${e.message}`)
        err('به حالت شبکه محلی برمی‌گردیم — بعداً با install.bat می‌توانید دوباره امتحان کنید')
        state.kind = 'local'
      }
    }
  } else {
    state.kind = 'quick'
    info('تونل سریع: آدرس تصادفی بعد از اجرای start-server نمایش داده می‌شود')
  }
  writeFileSync(statePath, JSON.stringify(state, null, 2))

  // ═══ Step 6 — start scripts ══════════════════════════════
  step(6, 'ساخت سرویس‌های اجرا')
  const win = process.platform === 'win32'
  const startBat = path.join(installDir, 'start-server.bat')
  const stopBat = path.join(installDir, 'stop-server.bat')
  const startSh = path.join(installDir, 'start-server.sh')
  if (win) {
    writeFileSync(startBat, `@echo off
chcp 65001 >nul
title MedPad Server v${INSTALLER_VER}
cd /d "%~dp0"
echo ════════════════════════════════════════
echo  MedPad v${INSTALLER_VER} — در حال اجرا
echo  پنل:      http://localhost:${PANEL_PORT}
for /f "usebackq delims=" %%u in (\`node -e "try{const s=require('./tunnel-state.json');if(s.publicUrl)console.log(s.publicUrl)}catch(e){}"\`) do echo  آدرس ثابت: %%u
echo ════════════════════════════════════════
start "MedPad-Realtime" /min cmd /c "cd /d "%~dp0panel" && set PORT=${RT_PORT} && set REALTIME_PORT=${RT_PORT} && node ..\\realtime\\index.js & pause"
cd panel
node node_modules\\next\\dist\\bin\\next start -p ${PANEL_PORT}
pause
`, 'utf8')
    writeFileSync(stopBat, `@echo off
taskkill /F /IM node.exe /FI "WINDOWTITLE eq MedPad*" >nul 2>&1
echo سرویس‌ها متوقف شدند
pause
`, 'utf8')
    ok('start-server.bat / stop-server.bat ساخته شد')
  }
  writeFileSync(startSh, `#!/usr/bin/env bash
cd "$(dirname "$0")"
node realtime/index.js &        # :${RT_PORT}
cd panel
node node_modules/next/dist/bin/next start -p ${PANEL_PORT}
`, 'utf8')
  try { require('fs').chmodSync(startSh, 0o755) } catch {}
  ok('start-server.sh ساخته شد')

  // ═══ Step 7 — health check ═══════════════════════════════
  step(7, 'بررسی سلامت')
  const busy = await portBusy(PANEL_PORT)
  if (busy) warn(`پورت ${PANEL_PORT} در حال استفاده است — اجرای start-server جدید ابتدا قدیمی را می‌بندد`)
  const nextBin = existsSync(path.join(panelDir, '.next', 'BUILD_ID'))
  if (nextBin) ok('بیلد production تأیید شد')
  else err('بیلد production یافت نشد')

  const mins = ((Date.now() - t0) / 60000).toFixed(1)
  console.log(`
🎉 نصب کامل شد (${mins} دقیقه)

  ▶ اجرای پنل:      ${win ? 'start-server.bat' : './start-server.sh'}
  ▶ پنل محلی:       http://localhost:${PANEL_PORT}
${state.publicUrl ? `  ▶ آدرس ثابت:      ${state.publicUrl}\n` : ''}  ▶ ورود مدیر:      ${adminUser} / ${adminPass ? '(رمزی که انتخاب کردید)' : '(رمز قبلی شما)'}
  ▶ اپ اندروید:     آدرس سرور را در صفحه ورود اپ وارد کنید
`)
}

main().catch((e) => {
  err(`خطای غیرمنتظره: ${e.message}`)
  process.exit(1)
})
