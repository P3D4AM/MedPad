@echo off
chcp 65001 >nul 2>&1
setlocal EnableDelayedExpansion
title MedPad Installer v1.9.3

REM ── self-elevation (UAC) — v1.9.2: old locked Prisma DLL was caused by
REM ── services running elevated while installer was not.
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo requesting administrator access ...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo.
echo ==============================================
echo   MedPad Installer v1.9.3  [elevated]
echo ==============================================
echo.

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [X] Node.js not found. Install from https://nodejs.org (LTS) then re-run.
    pause
    exit /b 1
)
for /f "delims=" %%v in ('node --version') do set NODEV=%%v
echo [OK] Node.js !NODEV!

node "%~dp0install.mjs" %*
set EXITCODE=%errorlevel%
echo.
if %EXITCODE% neq 0 (
    echo [X] install failed with code %EXITCODE% - see messages above
) else (
    echo [OK] install finished - run start-server.bat
)
pause
exit /b %EXITCODE%
