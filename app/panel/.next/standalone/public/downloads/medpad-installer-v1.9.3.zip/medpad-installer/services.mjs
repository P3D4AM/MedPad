/**
 * MedPad services helper — stop old processes reliably (v1.9.2+)
 * Two-pass kill with REAL verification (the silent-failure EPERM bug fix).
 */
import { exec } from 'child_process'
import { promisify } from 'util'
import { existsSync, readFileSync } from 'fs'
import path from 'path'
const pexec = promisify(exec)

export function pidFile(dir) {
  return path.join(dir, '.medpad.pids')
}

export function readPids(dir) {
  try {
    return JSON.parse(readFileSync(pidFile(dir), 'utf8'))
  } catch {
    return { pids: [] }
  }
}

function psList() {
  return new Promise((resolve) => {
    const cmd =
      process.platform === 'win32'
        ? 'tasklist /FO CSV /NH'
        : 'ps -eo pid=,comm='
    exec(cmd, { timeout: 8000 }, (err, stdout) => {
      if (err) return resolve([])
      const rows = stdout.split(/\r?\n/).filter(Boolean)
      const out = rows.map((line) => {
        if (process.platform === 'win32') {
          const m = line.match(/^"([^"]+)","(\d+)/)
          return m ? { name: m[1].toLowerCase(), pid: Number(m[2]) } : null
        }
        const parts = line.trim().split(/\s+/, 2)
        return { name: (parts[1] || '').toLowerCase(), pid: Number(parts[0]) }
      })
      resolve(out.filter(Boolean))
    })
  })
}

function kill(pid, force) {
  return new Promise((resolve) => {
    const cmd =
      process.platform === 'win32'
        ? `taskkill /PID ${pid} ${force ? '/F' : ''}`
        : `kill ${force ? '-9' : ''} ${pid}`.trim()
    exec(cmd, { timeout: 5000 }, () => resolve())
  })
}

/**
 * Kill processes belonging to a previous MedPad install (node/cloudflared/rt).
 * Returns { killed: n, verified: bool } — verified=false means something
 * survived and the caller MUST warn loudly (root cause of the EPERM bug).
 */
export async function stopMedPadServices(dir, { ourNames = ['node', 'node.exe', 'bun', 'bun.exe', 'cloudflared', 'cloudflared.exe'] } = {}) {
  const saved = readPids(dir).pids || []
  let killed = 0

  for (const pid of saved) {
    await kill(pid, false)
  }
  await new Promise((r) => setTimeout(r, 1200))
  for (const pid of saved) {
    await kill(pid, true)
  }

  // also kill anything listening on our ports
  const ports = [3000, 3003]
  for (const port of ports) {
    try {
      if (process.platform === 'win32') {
        const { stdout } = await pexec(`netstat -ano | findstr :${port} | findstr LISTENING`).catch(() => ({ stdout: '' }))
        for (const m of stdout.matchAll(/\s(\d+)\s*$/gm)) await kill(Number(m[1]), true)
      } else {
        const { stdout } = await pexec(`lsof -t -i :${port} 2>/dev/null || fuser ${port}/tcp 2>/dev/null`).catch(() => ({ stdout: '' }))
        for (const line of stdout.split(/\s+/).filter(Boolean)) await kill(Number(line), true)
      }
    } catch {
      /* port free */
    }
  }

  // verification pass
  const alive = await psList()
  const survivors = saved.filter((pid) => alive.some((p) => p.pid === pid))
  killed = saved.length - survivors.length
  return { killed, verified: survivors.length === 0, survivors }
}

/** Is anything listening on port? (best-effort) */
export async function portBusy(port) {
  try {
    if (process.platform === 'win32') {
      const { stdout } = await pexec(`netstat -ano | findstr :${port} | findstr LISTENING`)
      return stdout.trim().length > 0
    }
    const { stdout } = await pexec(`lsof -i :${port} 2>/dev/null | grep LISTEN || true`)
    return stdout.trim().length > 0
  } catch {
    return false
  }
}

export { existsSync }
