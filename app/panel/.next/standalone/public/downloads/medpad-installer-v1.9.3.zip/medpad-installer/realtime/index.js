/**
 * MedPad Realtime Service (installer version) — Node.js, plain ESM.
 * Same behavior as the sandbox mini-service: socket.io on :3003 + /emit endpoint.
 */
import { createServer } from 'node:http'
import { Server } from 'socket.io'

const PORT = Number(process.env.REALTIME_PORT || 3003)
const TOKEN = process.env.SOCKET_TOKEN || 'medpad-dev-token'

const httpServer = createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'content-type')
  if (req.method === 'OPTIONS') {
    res.writeHead(204)
    res.end()
    return
  }

  const url = new URL(req.url || '/', `http://localhost:${PORT}`)

  if (req.method === 'GET' && url.pathname === '/health') {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ ok: true, service: 'medpad-realtime', clients: io.engine.clientsCount }))
    return
  }

  if (req.method === 'POST' && url.pathname === '/emit') {
    let body = ''
    req.on('data', (c) => (body += c))
    req.on('end', () => {
      try {
        const { token, event, payload } = JSON.parse(body || '{}')
        if (token !== TOKEN) {
          res.writeHead(401, { 'content-type': 'application/json' })
          res.end(JSON.stringify({ ok: false, error: 'bad token' }))
          return
        }
        if (!event || typeof event !== 'string') {
          res.writeHead(400, { 'content-type': 'application/json' })
          res.end(JSON.stringify({ ok: false, error: 'missing event' }))
          return
        }
        io.emit(event, payload ?? {})
        console.log(`[emit] ${event}`)
        res.writeHead(200, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ ok: true }))
      } catch {
        res.writeHead(400, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ ok: false, error: 'bad json' }))
      }
    })
    return
  }

  res.writeHead(404, { 'content-type': 'application/json' })
  res.end(JSON.stringify({ ok: false, error: 'not found' }))
})

const io = new Server(httpServer, {
  path: '/socket.io',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
})

io.on('connection', (socket) => {
  console.log(`[rt] panel connected: ${socket.id}`)
  socket.on('disconnect', () => console.log(`[rt] disconnected: ${socket.id}`))
})

httpServer.listen(PORT, () => {
  console.log(`✔ MedPad realtime listening on :${PORT}`)
})
