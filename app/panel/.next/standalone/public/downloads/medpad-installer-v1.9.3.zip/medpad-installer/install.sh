#!/usr/bin/env bash
# MedPad Installer v1.9.3 — Linux / macOS
set -e
cd "$(dirname "$0")"

echo ""
echo "════════════════════════════════════════"
echo "  MedPad Installer v1.9.3 — linux/macOS"
echo "════════════════════════════════════════"

if ! command -v node >/dev/null 2>&1; then
  echo "✗ Node.js نصب نیست — از https://nodejs.org نصب کنید (LTS)"
  exit 1
fi
node --version

node install.mjs "$@"
