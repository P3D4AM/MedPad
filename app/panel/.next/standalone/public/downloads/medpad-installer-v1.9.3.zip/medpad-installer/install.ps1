# MedPad Installer v1.9.3 — PowerShell bootstrap (called by install.bat)
# Self-elevation is handled by install.bat; this script runs the node pipeline.
$ErrorActionPreference = 'Stop'

Write-Host ''
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host '  MedPad Installer v1.9.3' -ForegroundColor Cyan
Write-Host '==============================================' -ForegroundColor Cyan

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host '[X] Node.js not found — install from https://nodejs.org (LTS)' -ForegroundColor Red
  exit 1
}

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
& node "$dir\install.mjs" @args
exit $LASTEXITCODE
